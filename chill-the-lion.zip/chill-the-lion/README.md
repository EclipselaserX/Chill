# Chill the lion

A Pen created on CodePen.io. Original URL: [https://codepen.io/Yakudoo/pen/YXxmYR](https://codepen.io/Yakudoo/pen/YXxmYR).

WebGL experiment using ThreeJS. Move the fan and press to make wind, the lion will surely appreciate.